Changelog
=========

[0.0.1] - 2024-11-12
--------------------

### New Features

- feat: Import code for role (#3)

### Other Changes

- refactor: Use vars/RedHat_N.yml symlink for CentOS, Rocky, Alma wherever possible (#1)

